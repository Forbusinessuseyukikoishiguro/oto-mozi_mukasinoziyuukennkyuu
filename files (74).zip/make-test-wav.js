/* ============================================================================
 * make-test-wav.js — テスト用のWAVファイルを生成するスクリプト
 * ----------------------------------------------------------------------------
 * 目的:
 *   分割・結合・保存などの動作確認に使う音声を、手元で作ります。
 *   実際の会議音声を使わずに済むため、個人情報の混入も防げます。
 *
 * 使い方:
 *   node make-test-wav.js        → test/sample-2min.wav（既定の2分）を作成
 *   node make-test-wav.js 5      → test/sample-5min.wav（5分）を作成
 *
 * 音の中身:
 *   440Hz のサイン波（ただの音）。内容の認識結果は期待しません。
 *   ファイルの長さと分割数の確認が目的です。
 * ============================================================================ */

const fs = require("fs");
const path = require("path");

// 引数（分）。省略時は2分。数値でない場合も2分として扱う
const minutes = Number(process.argv[2] || 2) || 2;

const RATE = 16000;            // サンプリング周波数（16kHz・アプリの変換後と同じ）
const CHANNELS = 1;            // モノラル
const BITS = 16;               // 16bit
const seconds = minutes * 60;  // 総秒数
const n = RATE * seconds;      // 総サンプル数

// 44バイトのヘッダー ＋ 1サンプル2バイトの音声データ
const buf = Buffer.alloc(44 + n * 2);

// RIFFヘッダー
buf.write("RIFF", 0);
buf.writeUInt32LE(36 + n * 2, 4);
buf.write("WAVE", 8);

// fmtチャンク（PCM・モノラル・16kHz・16bit）
buf.write("fmt ", 12);
buf.writeUInt32LE(16, 16);
buf.writeUInt16LE(1, 20);            // 1 = PCM
buf.writeUInt16LE(CHANNELS, 22);
buf.writeUInt32LE(RATE, 24);
buf.writeUInt32LE(RATE * 2, 28);     // バイトレート
buf.writeUInt16LE(2, 32);            // ブロックサイズ（1サンプルのバイト数）
buf.writeUInt16LE(BITS, 34);

// dataチャンク（音声本体）
buf.write("data", 36);
buf.writeUInt32LE(n * 2, 40);

// 440Hzのサイン波を、音量30%で書き込む
for (let i = 0; i < n; i++) {
  const t = i / RATE;
  const v = Math.sin(2 * Math.PI * 440 * t) * 0.3;
  buf.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
}

// 出力先（test フォルダ）を作成して保存
const dir = path.join(__dirname, "test");
fs.mkdirSync(dir, { recursive: true });
const out = path.join(dir, `sample-${minutes}min.wav`);
fs.writeFileSync(out, buf);
console.log(`作成しました: ${out}（${(buf.length / 1048576).toFixed(1)} MB, ${minutes}分）`);
