/* ============================================================================
 * config.mock.js — テスト専用の設定（APIキー不要）
 * ----------------------------------------------------------------------------
 * 使い方:
 *   1. 本番用の config.js を config.real.js に名前変更して退避する
 *   2. この config.mock.js を config.js という名前でコピーする
 *   3. テスト終了後、config.real.js を config.js に戻す
 *
 * 注意:
 *   - endpoint は mock-server.js（localhost:8787）を指します。Azureには接続しません。
 *   - apiKey は mock-server.js の KEY と一致させてください。
 *   - 課金は発生しません。
 * ============================================================================ */
window.APP_CONFIG = Object.freeze({
  endpoint: "http://localhost:8787",   // mock-server.js の待ち受けアドレス
  apiKey: "mock-key",                  // mock-server.js が正しいキーとして扱う値
  apiVersion: "2024-11-15",
  locale: "ja-JP",
  defaultSegmentMinutes: 1,            // テストは短い分割単位（1分）で素早く確認する
  memWarnMB: 1500,
  requestTimeoutMs: 60000,             // テスト時は1分で打ち切る
});
