# AI用語集

**案件名**：
**最終更新日**：

## AI・生成AI用語
| 用語 | 読み／略語 | 定義 | NG表記 |
|---|---|---|---|

## 機械学習用語
| 用語 | 読み／略語 | 定義 | NG表記 |
|---|---|---|---|

## 略語一覧
| 略語 | 正式名称 | 説明 |
|---|---|---|
| LLM | Large Language Model | |
| RAG | Retrieval-Augmented Generation | |
| PoC | Proof of Concept | |
| MLOps | Machine Learning Operations | |

## 表記統一ルール
| 分類 | ルール | 例 |
|---|---|---|
| モデル名表記 | 公式表記に統一（版番号を含む） | |
| 英数字 | 半角に統一 | |
