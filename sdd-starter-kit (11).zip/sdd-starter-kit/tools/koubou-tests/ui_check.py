"""画面層のシステムテスト（Playwright + Chromium）。全タブを開き、操作し、エラーが出ないことを確かめる"""
import sys, pathlib
from playwright.sync_api import sync_playwright
html = pathlib.Path(sys.argv[1]).resolve()
shots = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else None
src = "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'></head><body>" + html.read_text(encoding="utf-8") + "</body></html>"
errors, n = [], 0
with sync_playwright() as p:
    b = p.chromium.launch()
    for w, scheme in [(1280, "light"), (390, "dark")]:
        pg = b.new_page(viewport={"width": w, "height": 900}, color_scheme=scheme)
        pg.on("pageerror", lambda e: errors.append(str(e)))
        pg.on("console", lambda m: m.type == "error" and errors.append(m.text))
        pg.set_content(src)
        tabs = pg.locator("nav button")
        assert tabs.count() == 12, tabs.count()
        for i in range(tabs.count()):
            tabs.nth(i).click(); n += 1
            sw = pg.evaluate("document.documentElement.scrollWidth"); cw = pg.evaluate("document.documentElement.clientWidth")
            assert sw <= cw + 1, f"横スクロール {w}px tab{i}: {sw}>{cw}"
            if shots: pg.screenshot(path=str(shots / f"tab{i}-{w}.png"), full_page=False)
        # 学習（記事全文）
        tabs.nth(0).click(); assert pg.locator("[data-art]").count() == 6; n += 1
        pg.click("[data-art='a3']"); assert "AI事業者ガイドライン" in pg.inner_text("#lnToc"); n += 1
        assert pg.locator("#lnDoc .mm").count() >= 3; assert pg.locator("#lnDoc .codeblk").count() >= 10; n += 1
        pg.locator("#lnToc [data-read]").first.check(); assert "読了 1/" in pg.inner_text("[data-art='a3']"); n += 1
        pg.fill("#lnSearch", "FISC"); pg.locator("[data-hit]").first.click(); assert "金融" in pg.inner_text("#lnDoc"); n += 1
        # 仕様書サンプル：記事の原文
        tabs.nth(1).click(); assert pg.locator("[data-ab]").count() >= 60; n += 1
        pg.select_option("#abArt", "a5"); pg.locator("[data-ab]").first.click(); pg.click("#abRead"); assert pg.locator("#lnDoc").count() == 1; n += 1
        tabs.nth(1).click(); pg.click("[data-s='1']"); pg.click("#smpRead"); assert "振込依頼" in pg.inner_text("#lnDoc"); n += 1
        # 仕様チェッカー
        tabs.nth(2).click(); pg.click("#lintGood"); assert "指摘はありません" in pg.inner_text("#lintOut"); n += 1
        pg.click("#lintBad"); assert "重複" in pg.inner_text("#lintOut"); n += 1
        pg.select_option("#lintSample", "fin"); assert "指摘はありません" in pg.inner_text("#lintOut"); n += 1
        # 仕様書サンプル → チェッカー・依頼文へ
        tabs.nth(1).click(); pg.click("[data-s='2']"); assert "保険" in pg.inner_text("#smpInfo"); assert "FR-008" in pg.inner_text("#smpReqs"); n += 1
        pg.click("#smpLint"); assert "SPEC-INS-001" in pg.input_value("#specIn"); assert "指摘はありません" in pg.inner_text("#lintOut"); n += 1
        tabs.nth(1).click(); pg.click("#smpHoles"); assert "二重処理" in pg.inner_text("#pOut"); n += 1
        # ヒアリング
        tabs.nth(3).click(); pg.fill("#h_a3", "なるべく速く"); assert "M/S/C/W" in pg.inner_text("#hFollow"); n += 1
        # 要求文ビルダー
        tabs.nth(4).click(); pg.fill("#rAction", "結果を表示する"); assert "表示しなければならない" in pg.inner_text("#rOut"); n += 1
        # テスト設計
        tabs.nth(5).click(); pg.fill("#bMax", "300"); assert "301行" in pg.inner_text("#bOut"); n += 1
        # プロンプト
        tabs.nth(6).click(); pg.select_option("#pKind", "error"); assert "まだ修正はしないでください" in pg.inner_text("#pOut"); n += 1
        # テンプレート
        tabs.nth(7).click(); pg.click("[data-t='2']"); assert "合意事項シート" in pg.inner_text("#tOut"); n += 1
        # 出荷判定
        tabs.nth(8).click()
        for c in pg.locator("[data-g]").all(): c.check()
        assert "判定会に出せます" in pg.inner_text("#gVerdict"); n += 1
        # AIガイドライン点検
        tabs.nth(9).click(); assert "判断者が空" in pg.inner_text("#gwIssues"); n += 1
        pg.fill("#gwOwner", "石黒"); pg.select_option("[data-b='H-08']", "非該当")
        assert "非該当の理由がない" in pg.inner_text("#gwIssues"); n += 1
        pg.fill("[data-b='H-08'][data-k='reason']", "基盤モデルを開発しない"); assert "基盤モデルを開発しない" in pg.inner_text("#gwOut"); n += 1
        # 規格
        tabs.nth(10).click(); pg.select_option("#sPhase", "テスト"); assert "29119" in pg.inner_text("#sBody"); n += 1
        pg.select_option("#sPhase", "すべて"); pg.select_option("#sKind", "金融・保険"); assert "FISC" in pg.inner_text("#sBody"); n += 1
        # クイズ
        tabs.nth(11).click(); pg.locator("[data-q='0'][data-o='0']").click(); assert "1 / 23" in pg.inner_text("#qScore"); n += 1
        # コピー
        tabs.nth(7).click(); pg.click("[data-copy='tOut']"); pg.wait_for_timeout(200); n += 1
        if shots: pg.screenshot(path=str(shots / f"final-{w}.png"))
        pg.close()
    b.close()
assert not errors, errors
print(f"OK {n} UI checks, no page errors")
