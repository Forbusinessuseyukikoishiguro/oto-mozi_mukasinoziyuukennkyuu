// うさうさ仕様駆動工房 ロジック層の回帰テスト（node だけで動く。DOM不要）
const fs = require("fs"), vm = require("vm"), assert = require("assert");
const html = fs.readFileSync(process.argv[2] || __dirname + "/../sdd-koubou.html", "utf8");
const grab = id => html.match(new RegExp('<script id="' + id + '"[^>]*>([\\s\\S]*?)</script>'))[1];
const ctx = {module:{}}; vm.createContext(ctx);
vm.runInContext(grab("logic") + "\n;this.SDD=SDD;", ctx);
vm.runInContext(grab("data") + "\n;this.DATA=DATA;", ctx);
vm.runInContext(grab("samples") + "\n;this.SAMPLES=SAMPLES;", ctx);
const ARTS = JSON.parse(html.match(/<script id="articles" type="application\/json">([\s\S]*?)<\/script>/)[1]);
// 画面層も構文だけ確認
new vm.Script(grab("ui"));
const S = ctx.SDD, D = ctx.DATA, SM = ctx.SAMPLES;
let n = 0; const t = (name, fn) => { fn(); n++; };

t("悪い例：重複・GWTなし・曖昧語・テストなしを検出", () => {
  const r = S.lintSpec(D.sampleSpec, D.sampleTrace), c = S.countBy(r.findings);
  const msg = r.findings.map(f => f.message).join("\n");
  assert(/重複/.test(msg)); assert(/Given/.test(msg)); assert(/いい感じ/.test(msg)); assert(/速く/.test(msg));
  assert(/複数の動作/.test(msg)); assert(/欠番：FR-003, FR-004/.test(msg));
  assert(r.reqs.find(q => q.id === "FR-005").tested === true);
  assert(r.reqs.find(q => q.id === "FR-002").tested === false);
  assert(c["高"] >= 4);
});
t("良い例：指摘0件", () => {
  const r = S.lintSpec(D.goodSpec, "FR-001 FR-002 FR-003");
  assert.strictEqual(r.findings.length, 0, JSON.stringify(r.findings));
});
t("テスト一覧が空なら『テストなし』は出さない", () => {
  const r = S.lintSpec(D.goodSpec, "");
  assert(!r.findings.some(f => /テストが1つもない/.test(f.message)));
});
t("要求見出しがない", () => assert.strictEqual(S.lintSpec("# なにか", "").findings[0].level, "高"));
t("測定環境なしの時間基準は低", () => {
  const r = S.lintSpec("## FR-001 a\nシステムは、読み込まなければならない。\n- Given x / When y / Then 5秒以内に完了する", "");
  assert(r.findings.some(f => f.level === "低" && /測定環境/.test(f.message)));
});
t("活用：する／五段／一段", () => {
  assert.strictEqual(S.obligationPhrase("読み込む"), "読み込まなければならない");
  assert.strictEqual(S.obligationPhrase("表示する", "してはならない"), "表示してはならない");
  assert.strictEqual(S.obligationPhrase("置き換える"), "置き換えなければならない");
  assert.strictEqual(S.obligationPhrase("送る", "してもよい"), "送ってもよい");
  assert.strictEqual(S.obligationPhrase("出力する", "することが望ましい"), "出力することが望ましい");
  assert.strictEqual(S.obligationPhrase("読み込む", "してはならない"), "読み込んではならない");
});
t("要求文ビルダーの出力は点検を通る", () => {
  const md = S.buildRequirement({id:"FR-001", title:"CSV読み込み", action:"UTF-8のCSVを読み込む", given:"1000行のCSV", when:"読み込む", then:"5秒以内に完了する", env:"Windows 11"});
  assert(/読み込まなければならない。/.test(md));
  assert.strictEqual(S.lintSpec(md, "").findings.length, 0, JSON.stringify(S.lintSpec(md, "").findings));
});
t("境界値：0〜1000（下限の直前は除く）", () => {
  const b = S.boundaryCases(0, 1000, {req:"FR-001"});
  assert.deepStrictEqual(Array.from(b.cases.map(c => c.value)), [0, 1, 999, 1000, 1001]);
  assert.strictEqual(b.cases[4].valid, false); assert.strictEqual(b.cases[0].id, "TC-001");
});
t("境界値：1〜3 で重複を除く", () => {
  const b = S.boundaryCases(1, 3);
  assert.deepStrictEqual(Array.from(b.cases.map(c => c.value)), [0, 1, 2, 3, 4]);
  assert.strictEqual(b.cases[0].valid, false);
});
t("境界値：入力エラー", () => assert(S.boundaryCases(10, 1).error));
t("デシジョンテーブル：2条件で4ケース・5条件はエラー", () => {
  const d = S.decisionTable(["A", "B"]);
  assert.strictEqual(d.cols, 4); assert(/\| A \| Y \| Y \| N \| N \|/.test(d.md)); assert(/\| B \| Y \| N \| Y \| N \|/.test(d.md));
  assert(S.decisionTable(["a","b","c","d","e"]).error); assert(S.decisionTable([""]).error);
});
t("曖昧語から質問を作る", () => {
  const f = S.followUps("いい感じに速くしたい");
  assert.deepStrictEqual(Array.from(f.map(x => x.word)), ["いい感じ", "速く"]);
});
t("ヒアリング記録に聞き返しが入る・表の区切りを壊さない", () => {
  const md = S.hearingToMd(D.hearing, {a2:"いい感じ|に"});
  assert(/「いい感じ」/.test(md)); assert(/いい感じ／に/.test(md));
});
t("出荷判定：全部済みでのみ ready", () => {
  const all = {}; S.GATES.forEach(g => all[g.id] = true);
  assert.strictEqual(S.gateVerdict(all).ready, true);
  delete all.G4; const r = S.gateVerdict(all);
  assert.strictEqual(r.ready, false); assert.strictEqual(r.missing.length, 1); assert(/決定者/.test(r.md));
});
t("プロンプト：全種類が要求IDを含み、判断を人に残す", () => {
  Object.keys(S.PROMPTS).forEach(k => {
    const p = S.buildPrompt(k, {id:"FR-009", extra:"補足X"});
    assert(p.length > 50, k);
    if (!["options","hearing","delivery","review","aigl"].includes(k)) assert(p.includes("FR-009"), k);
    assert(/(私|人|推奨は書かない|推測)/.test(p), k);
    assert(!/\n\n\n/.test(p), k);
  });
  assert(S.buildPrompt("plan", {id:"FR-1"}).includes("まだコードは書かない"));
  assert(S.buildPrompt("error", {}).includes("まだ修正はしないでください"));
});
t("データ：クイズの正解番号が範囲内・テンプレに本文", () => {
  D.quiz.forEach((q, i) => assert(q.a >= 0 && q.a < q.o.length, "quiz " + i));
  D.templates.forEach(x => assert(x.body.length > 20, x.id));
  assert(D.standards.length >= 12);
});
t("版数は APP にだけ書く（直書き禁止）", () => {
  const outside = html.replace(grab("logic"), "");
  assert(!/PRO v\d/.test(outside));
});
t("仕様書サンプル：5件、理由・意図つきで指摘0件", () => {
  assert(SM.length >= 5);
  SM.forEach(x => {
    const r = S.lintSpec(x.spec, "", {reason:true});
    assert.strictEqual(r.findings.length, 0, x.id + " " + JSON.stringify(r.findings));
    assert(r.reqs.length >= 3, x.id); assert(x.judge.length >= 2, x.id);
    assert(/架空|研修用/.test(x.spec) || x.id === "survey", x.id);
  });
});
t("理由・意図の点検はオプション", () => {
  const md = "## FR-001 a\nシステムは、読み込まなければならない。\n- Given x / When y / Then z";
  assert.strictEqual(S.lintSpec(md, "").findings.length, 0);
  assert(S.lintSpec(md, "", {reason:true}).findings.some(f => /理由・意図/.test(f.message)));
});
t("規格マップ：分類ごとに揃っている", () => {
  ["国際","AI","国内","金融・保険"].forEach(k => assert(D.standards.filter(x => x.kind === k).length >= 4, k));
  assert(D.standards.some(x => /非機能要求グレード/.test(x.code)));
  assert(D.templates.length >= 28); assert(D.quiz.length >= 23);
});
t("穴探しの依頼文は推奨・条文引用をさせない", () => {
  const p = S.buildPrompt("holes", {id:"FR-003"});
  assert(/推奨は書かない/.test(p) && /条文を記憶で引用しない/.test(p) && /二重処理/.test(p));
  assert(/条項番号や文言を引用しない/.test(S.buildPrompt("review", {})));
});
t("AIガイドライン点検：未判断・理由なし・判断者なしを検出", () => {
  const empty = S.guidelineIssues({});
  assert(empty.some(i => i.id === "全体" && i.level === "高"));
  assert.strictEqual(empty.filter(i => /^G-/.test(i.id)).length, 9);
  assert.strictEqual(empty.filter(i => /^H-/.test(i.id)).length, 12);
  const st = {owner:"石黒", a:{}, b:{}};
  S.AIGL_7A.forEach(g => st.a[g.id] = {status:"確認済", criteria:"個人情報0件"});
  S.AIGL_7B.forEach(h => st.b[h.id] = {apply:"該当", reason:"自社の範囲で実施"});
  assert.strictEqual(S.guidelineIssues(st).length, 0);
  st.b["H-08"] = {apply:"非該当", reason:""};
  assert(S.guidelineIssues(st).some(i => i.id === "H-08" && i.level === "高"));
  st.a["G-03"] = {status:"確認済", criteria:""};
  assert(S.guidelineIssues(st).some(i => i.id === "G-03" && /合格基準/.test(i.message)));
  const md = S.guidelineMd(st);
  assert(/第1\.2版/.test(md) && /自己点検/.test(md) && /\| G-09 \|/.test(md) && /⑫/.test(md));
  assert(S.buildPrompt("aigl", {}).includes("該当判断（該当／非該当）は書かない"));
  assert(S.GATES.some(g => g.id === "A6"));
});
t("学習：6本の全文が入り、本文の行がすべて表示に出る（消えていない）", () => {
  assert.strictEqual(ARTS.length, 6);
  const dec = h => h.replace(/<[^>]+>/g, "").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&amp;/g,"&").replace(/\s+/g,"");
  ARTS.forEach(a => {
    const r = S.mdToHtml(a.md, a.id), text = dec(r.html);
    let inCode = false, checked = 0, missing = [];
    a.md.split("\n").forEach(l => {
      if (/^```/.test(l)) { inCode = !inCode; return; }
      if (inCode) { const y = l.replace(/\s+/g, "").slice(0, 18); if (y) { checked++; if (text.indexOf(y.replace(/&/g,"&")) < 0) missing.push(y); } return; }
      let x = l.replace(/^>\s?/, "").replace(/^#{1,6}\s+|^\s*[-*]\s+(\[.\]\s+)?|^\s*\d+\.\s+|^>\s?|^:::(message alert|message|details)\s*|:::$/g, "").replace(/\*\*/g, "").replace(/`/g, "");
      if (!inCode && /^\s*\|/.test(l)) x = l.split("|").map(c => c.replace(/\*\*/g,"").replace(/`/g,"").trim()).filter(c => c && !/^:?-+:?$/.test(c)).join(" ");
      if (/^(flowchart|stateDiagram|graph )/.test(l.trim()) || (inCode && /-->|\[\*\]/.test(l))) return;
      x = x.replace(/\[([^\]]+)\]\((https?:[^)]+)\)/g, "$1").replace(/<br>/g, " ").replace(/\s+/g, " ").trim();
      if (!x || /^-{3,}$/.test(x)) return;
      const probe = x.replace(/\s+/g, "").slice(0, 18); checked++;
      if (text.indexOf(probe) < 0) missing.push(probe);
    });
    assert.strictEqual(missing.length, 0, a.id + " missing: " + JSON.stringify(missing.slice(0, 5)));
    assert(checked > 50, a.id);
  });
});
t("学習：見出し・表・コード・メッセージ・mermaid を描画", () => {
  const r = S.mdToHtml("## A\n\n| a | b |\n|---|---|\n| 1 | **2** |\n\n```python:x.py\nprint(1<2)\n```\n\n:::message alert\n注意 **重要**\n:::\n\n:::details 答え例\n答え\n:::\n\n- [ ] チェック\n1. 一\n2. 二", "t");
  assert(/<h3 id="t-s1">A<\/h3>/.test(r.html) && /<td><strong>2<\/strong><\/td>/.test(r.html) && /print\(1&lt;2\)/.test(r.html));
  assert(/md-msg alert/.test(r.html) && /<details class="md-details"><summary>答え例/.test(r.html) && /☐/.test(r.html) && /<ol>/.test(r.html));
  const m = S.mermaidToHtml("flowchart LR\n  A[要求] --> B[仕様]\n  B --> C[評価]\n  C -->|ずれ| B");
  assert(/mm-box">要求/.test(m) && /mm-box">評価/.test(m) && /ずれ/.test(m));
  assert(/今の状態/.test(S.mermaidToHtml("stateDiagram-v2\n  [*] --> 受付\n  受付 --> 完了: 終了")));
  assert(!/<script/i.test(S.mdToHtml("<script>alert(1)</script>").html));
});
t("学習：検索と、記事からの原文抽出", () => {
  const hits = S.searchArticles(ARTS, "非該当");
  assert(hits.length > 3 && hits.some(h => h.id === "a3"));
  assert.strictEqual(S.searchArticles(ARTS, "x").length, 0);
  const all = []; ARTS.forEach(a => S.extractBlocks(a.md).forEach(b => all.push(b)));
  assert(all.length >= 60);
  assert(all.some(b => /## FR-001 CSV読み込み/.test(b.body)));
  assert(all.some(b => /ADR-001 重複送信の防止方式/.test(b.body)));
});
console.log("OK " + n + " tests");
