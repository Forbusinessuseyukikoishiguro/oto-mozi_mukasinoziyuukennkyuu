"""仕様の機械点検（ISO/IEC/IEEE 29148 の「良い要求」の観点を参考にした簡易チェック）

使い方：python tools/spec_lint.py [--spec docs/02-spec] [--tests tests docs/04-test]
- 標準ライブラリだけで動きます
- 終了コード：0 = 重大度「高」なし／1 = 「高」あり（CIの品質ゲート①で使う）
- 機械点検は見落とし防止の補助です。仕様の良し悪しの判断は人が行います
"""
from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# 曖昧語：検証できない書き方になりやすい語（必要に応じて追加）
VAGUE = ["など", "等の", "適切に", "必要に応じて", "なるべく", "できるだけ", "いい感じ", "速やかに",
         "十分な", "柔軟に", "使いやすい", "わかりやすい", "高速に", "素早く", "速く", "ある程度", "随時"]
OBLIGATION = re.compile(r"(なければならない|てはならない|ことが望ましい|てもよい)")
REQ_HEAD = re.compile(r"^##\s+((?:FR|NFR)-(\d{3}))\s*(.*)$")
ID_ANY = re.compile(r"\b((?:FR|NFR)-\d{3})\b")


@dataclass
class Finding:
    level: str   # 高 / 中 / 低
    where: str
    message: str


def parse_requirements(spec_dir: Path):
    """要求見出し（## FR-001 題名）ごとに本文を集める"""
    reqs = []
    for f in sorted(spec_dir.glob("*.md")):
        current = None
        for no, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
            m = REQ_HEAD.match(line)
            if m:
                current = {"id": m.group(1), "num": int(m.group(2)), "title": m.group(3).strip(),
                           "file": f.name, "line": no, "body": []}
                reqs.append(current)
            elif line.startswith("#"):
                current = None
            elif current is not None:
                current["body"].append((no, line))
    return reqs


def lint(spec_dir: Path, trace_dirs: list[Path]) -> tuple[list[Finding], list[dict]]:
    out: list[Finding] = []
    reqs = parse_requirements(spec_dir)
    if not reqs:
        out.append(Finding("高", str(spec_dir), "要求（## FR-001 形式の見出し）が見つからない"))
        return out, reqs

    # ID の重複・欠番
    seen: dict[str, str] = {}
    for r in reqs:
        key = r["id"]
        if key in seen:
            out.append(Finding("高", f'{r["file"]}:{r["line"]}', f"要求IDが重複：{key}（{seen[key]} と同じ）"))
        seen[key] = f'{r["file"]}:{r["line"]}'
    for prefix in ("FR", "NFR"):
        nums = sorted({r["num"] for r in reqs if r["id"].startswith(prefix + "-")})
        missing = [n for n in range(1, (nums[-1] if nums else 0) + 1) if n not in nums]
        if missing:
            out.append(Finding("低", prefix, "欠番：" + ", ".join(f"{prefix}-{n:03d}" for n in missing)))

    for r in reqs:
        where = f'{r["file"]}:{r["line"]} {r["id"]}'
        text = "\n".join(l for _, l in r["body"])
        statement = [l for _, l in r["body"] if l.strip() and not l.lstrip().startswith("-")]
        # 受入基準
        if not re.search(r"Given", text) or not re.search(r"Then", text):
            out.append(Finding("高", where, "受入基準（Given / When / Then）がない"))
        # 義務表現
        if not OBLIGATION.search(" ".join(statement)):
            out.append(Finding("中", where, "義務表現（しなければならない／してはならない 等）がない"))
        # 単一性（1要求に複数の動作）
        if any(len(re.findall(r"(し、|み、|り、|て、|かつ)", s)) >= 2 for s in statement):
            out.append(Finding("中", where, "1つの要求文に複数の動作がある可能性（分割を検討）"))
        # 曖昧語
        for no, line in r["body"]:
            for w in VAGUE:
                if w in line:
                    out.append(Finding("中", f'{r["file"]}:{no} {r["id"]}', f"曖昧語「{w}」：測れる条件にする"))
        # 数値の測定環境
        if re.search(r"\d+\s*(秒|ms|分)以内", text) and "測定環境" not in text:
            out.append(Finding("低", where, "時間の基準に測定環境が書かれていない"))

    # トレーサビリティ：テストから参照されていない要求
    referenced: set[str] = set()
    for d in trace_dirs:
        if not d.exists():
            continue
        for f in d.rglob("*"):
            if f.is_file() and f.suffix in {".py", ".md", ".jsonl"}:
                referenced |= set(ID_ANY.findall(f.read_text(encoding="utf-8", errors="ignore")))
    for r in reqs:
        r["tested"] = r["id"] in referenced
        if not r["tested"]:
            out.append(Finding("高", f'{r["file"]}:{r["line"]} {r["id"]}', "テストが1つもない（評価の抜け）"))

    # 文書管理
    overview = spec_dir / "00-overview.md"
    if not overview.exists():  # 1ファイルの仕様（冒頭に版のメタ情報がある）も受け付ける
        overview = next((f for f in sorted(spec_dir.glob("*.md")) if "版:" in f.read_text(encoding="utf-8")), overview)
    if overview.exists():
        ov = overview.read_text(encoding="utf-8")
        for key in ("版:", "状態:", "承認者:", "変更履歴", "未決事項", "対象外"):
            if key not in ov:
                out.append(Finding("中", overview.name, f"「{key}」の記載がない"))
    else:
        out.append(Finding("中", str(spec_dir), "00-overview.md（目的・スコープ・用語・版）がない"))
    return out, reqs


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec", default=str(ROOT / "docs" / "02-spec"))
    ap.add_argument("--tests", nargs="*", default=[str(ROOT / "tests"), str(ROOT / "docs" / "04-test")])
    a = ap.parse_args(argv)
    findings, reqs = lint(Path(a.spec), [Path(t) for t in a.tests])

    print(f"要求 {len(reqs)} 件を点検しました\n")
    print("| 要求ID | 題名 | テスト |")
    print("|---|---|---|")
    for r in reqs:
        print(f'| {r["id"]} | {r["title"]} | {"あり" if r.get("tested") else "なし"} |')
    print()
    order = {"高": 0, "中": 1, "低": 2}
    if findings:
        print("| 重大度 | 箇所 | 指摘 |")
        print("|---|---|---|")
        for f in sorted(findings, key=lambda x: order[x.level]):
            print(f"| {f.level} | {f.where} | {f.message} |")
    else:
        print("指摘はありません（最終判断は人が行います）")
    high = sum(1 for f in findings if f.level == "高")
    print(f"\n高 {high} 件／中 {sum(1 for f in findings if f.level == '中')} 件／低 {sum(1 for f in findings if f.level == '低')} 件")
    return 1 if high else 0


if __name__ == "__main__":
    sys.exit(main())
