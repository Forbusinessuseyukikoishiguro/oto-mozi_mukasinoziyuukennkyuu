"""FR-001 CSV読み込み / NFR-001 性能効率性"""
from __future__ import annotations

import csv
import io
from pathlib import Path

MAX_ROWS = 1000
REQUIRED_COLUMNS = ("question", "answer")


class LoadError(ValueError):
    """読み込みエラーの基底。message は利用者にそのまま見せる日本語。"""


class EncodingError(LoadError):
    pass


class RowLimitError(LoadError):
    pass


class ColumnError(LoadError):
    pass


def load_rows(path: str | Path, max_rows: int = MAX_ROWS) -> list[dict[str, str]]:
    """UTF-8（BOM可）のCSVを読み、行のリストを返す。

    優先順位（DEC-002）：文字コード不正 → 列不足 → 行数超過
    """
    raw = Path(path).read_bytes()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as e:
        raise EncodingError("文字コード不正：UTF-8で保存してください") from e

    reader = csv.DictReader(io.StringIO(text, newline=""))
    missing = [c for c in REQUIRED_COLUMNS if c not in (reader.fieldnames or [])]
    if missing:
        raise ColumnError(f"列不足：{', '.join(missing)} 列が必要です")

    rows = [{"question": (r.get("question") or "").strip(),
             "answer": (r.get("answer") or "").strip()} for r in reader]
    if len(rows) > max_rows:
        raise RowLimitError(f"行数超過：{len(rows)}行（上限{max_rows}行）")
    return rows


def group_by_question(rows: list[dict[str, str]]) -> dict[str, list[str]]:
    """設問ごとに回答をまとめる（出現順を保つ。空の回答は除く）"""
    groups: dict[str, list[str]] = {}
    for r in rows:
        q = r["question"]
        if not q:
            continue
        groups.setdefault(q, [])
        if r["answer"]:
            groups[q].append(r["answer"])
    return groups
