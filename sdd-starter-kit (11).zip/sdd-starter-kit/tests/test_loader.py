"""FR-001 CSV読み込み / NFR-001 性能効率性（境界値・同値分割・デシジョンテーブル）"""
import time

import pytest

from app.loader import ColumnError, EncodingError, RowLimitError, group_by_question, load_rows


def _write(tmp_path, n, encoding="utf-8", header="question,answer"):
    p = tmp_path / "in.csv"
    body = "\n".join(f"Q{i % 3},回答{i}" for i in range(n))
    p.write_bytes((header + "\n" + body).encode(encoding))
    return p


# TC-001〜TC-003（FR-001）境界値分析：上限1000行の前・ちょうど・直後、および下限
@pytest.mark.parametrize("n, ok", [
    (0, True),      # 下限（ヘッダのみ）
    (1, True),
    (999, True),    # 上限の直前
    (1000, True),   # 上限ちょうど
    (1001, False),  # 上限の直後
])
def test_row_limit_boundary(tmp_path, n, ok):
    p = _write(tmp_path, n)
    if ok:
        assert len(load_rows(p)) == n
    else:
        with pytest.raises(RowLimitError, match="行数超過"):
            load_rows(p)


# TC-004（FR-001）同値分割：文字コードが UTF-8 でない
def test_non_utf8_is_rejected(tmp_path):
    p = _write(tmp_path, 3, encoding="cp932")
    with pytest.raises(EncodingError, match="文字コード不正"):
        load_rows(p)


# TC-005（FR-001）同値分割：BOMつき UTF-8 は読める
def test_utf8_bom_is_accepted(tmp_path):
    p = _write(tmp_path, 3, encoding="utf-8-sig")
    assert load_rows(p)[0]["question"] == "Q0"


# TC-006（FR-001 / DEC-002）デシジョンテーブル：文字コード不正かつ行数超過 → 文字コード不正を優先
def test_encoding_error_has_priority_over_row_limit(tmp_path):
    p = _write(tmp_path, 1001, encoding="cp932")
    with pytest.raises(EncodingError):
        load_rows(p)


# TC-007（FR-001）異常系：必要な列がない
def test_missing_column(tmp_path):
    p = _write(tmp_path, 2, header="設問,回答")
    with pytest.raises(ColumnError, match="列不足"):
        load_rows(p)


# TC-008（FR-001）エラー推測：改行入りセル・空の回答
def test_multiline_cell_and_empty_answer(tmp_path):
    p = tmp_path / "in.csv"
    p.write_text('question,answer\nQ1,"1行目\n2行目"\nQ1,\n', encoding="utf-8")
    rows = load_rows(p)
    assert len(rows) == 2
    assert group_by_question(rows) == {"Q1": ["1行目\n2行目"]}


# TC-030（NFR-001）性能：1000行を5秒以内（CI環境での目安。正式な計測は測定環境で人が行う）
def test_load_1000_rows_within_5_seconds(tmp_path):
    p = _write(tmp_path, 1000)
    start = time.perf_counter()
    load_rows(p)
    assert time.perf_counter() - start < 5.0


# TC-009（FR-001 / DEC-002）デシジョンテーブル：優先順位は 文字コード不正 → 列不足 → 行数超過
@pytest.mark.parametrize("encoding, header, n, expected", [
    ("cp932", "設問,回答", 1001, EncodingError),       # 3つとも該当 → 文字コード不正
    ("utf-8", "設問,回答", 1001, ColumnError),          # 列不足＋行数超過 → 列不足
    ("utf-8", "question,answer", 1001, RowLimitError),  # 行数超過のみ
])
def test_error_priority(tmp_path, encoding, header, n, expected):
    p = _write(tmp_path, n, encoding=encoding, header=header)
    with pytest.raises(expected):
        load_rows(p)
