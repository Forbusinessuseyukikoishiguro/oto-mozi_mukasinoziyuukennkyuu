"""FR-002 / FR-003 AI出力の形式と不変条件"""
import json

from app.output_check import check_output


def test_valid_output():
    assert check_output(json.dumps({"summaries": ["a", "b"]}), 2) == []


def test_not_json():
    assert check_output("要約です", 1) == ["JSONとして解釈できない"]


def test_count_mismatch_and_name_leak():
    errs = check_output(json.dumps({"summaries": ["山田さんが好評"]}, ensure_ascii=False), 2)
    assert any("件数が不一致" in e for e in errs)
    assert any("個人名の疑い" in e for e in errs)


def test_too_long():
    errs = check_output(json.dumps({"summaries": ["あ" * 201]}), 1)
    assert errs and "長すぎる" in errs[0]
