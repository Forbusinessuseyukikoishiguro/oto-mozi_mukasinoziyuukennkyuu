"""FR-004 出力と終了コード / FR-005 ドライラン（仕様 v1.1 で追加）"""
import io
import json

from app.main import run


def _csv(tmp_path, text, encoding="utf-8"):
    p = tmp_path / "in.csv"
    p.write_bytes(text.encode(encoding))
    return p


class ExplodingClient:
    """呼ばれたら失敗する偽クライアント（AIを呼んでいないことの確認用）"""
    class _M:
        def create(self, **kwargs):
            raise AssertionError("ドライランでAIが呼ばれた")

    def __init__(self):
        self.messages = self._M()


# TC-040（FR-004）出力形式：summaries の各要素は question と summary の対。設問の順を保つ。終了コード0
def test_output_json_shape_and_exit_0(tmp_path):
    p = _csv(tmp_path, "question,answer\nQ1,a\nQ2,b\nQ1,c\nQ3,d\n")
    out = io.StringIO()
    assert run(str(p), dry_run=True, out=out) == 0
    data = json.loads(out.getvalue())
    assert [s["question"] for s in data["summaries"]] == ["Q1", "Q2", "Q3"]
    assert all(set(s) == {"question", "summary"} for s in data["summaries"])


# TC-041（FR-004 / FR-003）設問に含まれる敬称つきの個人名もマスキングされる
def test_question_is_masked(tmp_path):
    p = _csv(tmp_path, "question,answer\n山田さんの講義について,良かった\n")
    out = io.StringIO()
    run(str(p), dry_run=True, out=out)
    q = json.loads(out.getvalue())["summaries"][0]["question"]
    assert "山田" not in q and "[氏名]" in q


# TC-042（FR-004）境界値：見出し行だけ（0データ行）→ summaries 0件、終了コード0
def test_header_only_outputs_empty(tmp_path):
    p = _csv(tmp_path, "question,answer\n")
    out = io.StringIO()
    assert run(str(p), dry_run=True, out=out) == 0
    assert json.loads(out.getvalue()) == {"summaries": []}


# TC-043（FR-004）入力エラー：文言は標準エラー出力、標準出力は空、終了コード1
def test_input_error_goes_to_stderr_only(tmp_path, capsys):
    p = _csv(tmp_path, "設問,回答\nQ,a\n")
    out = io.StringIO()
    assert run(str(p), dry_run=True, out=out) == 1
    assert out.getvalue() == ""
    assert "列不足" in capsys.readouterr().err


# TC-044（FR-005）ドライランではAIを1回も呼ばない
def test_dry_run_never_calls_ai(tmp_path):
    p = _csv(tmp_path, "question,answer\nQ1,a\nQ2,b\n")
    out = io.StringIO()
    assert run(str(p), dry_run=True, client=ExplodingClient(), out=out) == 0
    assert len(json.loads(out.getvalue())["summaries"]) == 2


# TC-045（FR-005）回答0件の設問は「回答はありませんでした。」
def test_dry_run_question_without_answers(tmp_path):
    p = _csv(tmp_path, "question,answer\nQ1,\nQ2,b\n")
    out = io.StringIO()
    run(str(p), dry_run=True, out=out)
    s = json.loads(out.getvalue())["summaries"]
    assert s[0] == {"question": "Q1", "summary": "回答はありませんでした。"}


# TC-046（FR-005 / FR-003）ドライランの要約にも個人名が残らない
def test_dry_run_summary_is_masked(tmp_path):
    p = _csv(tmp_path, "question,answer\nQ1,佐藤さんが丁寧だった\n")
    out = io.StringIO()
    run(str(p), dry_run=True, out=out)
    assert "佐藤" not in out.getvalue()
