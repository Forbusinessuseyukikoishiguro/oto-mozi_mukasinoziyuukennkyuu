"""システムレベル：終了コードとログ（FR-001, NFR-003）"""
import io
import json
import logging
from pathlib import Path

from app.main import run

SAMPLE = Path(__file__).resolve().parents[1] / "data" / "sample.csv"


def test_dry_run_outputs_one_summary_per_question():
    out = io.StringIO()
    assert run(str(SAMPLE), dry_run=True, out=out) == 0
    data = json.loads(out.getvalue())
    assert len(data["summaries"]) == 3            # 設問3つ → 要約3件（FR-002）
    assert "山田" not in out.getvalue()            # 個人名が出力に残らない（FR-003）


def test_encoding_error_exit_code_1(tmp_path, capsys):
    p = tmp_path / "bad.csv"
    p.write_bytes("question,answer\nQ,回答".encode("cp932"))
    assert run(str(p), dry_run=True) == 1
    assert "文字コード不正" in capsys.readouterr().err


# TC-032（NFR-003）ログに個人名が出ない
def test_no_names_in_log(caplog):
    caplog.set_level(logging.INFO)
    run(str(SAMPLE), dry_run=True, out=io.StringIO())
    assert "山田" not in caplog.text
