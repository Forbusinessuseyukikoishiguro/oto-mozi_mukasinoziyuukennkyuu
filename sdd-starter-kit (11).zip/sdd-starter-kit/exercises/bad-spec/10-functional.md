# 機能要求（演習用：わざと悪く書いた仕様）
# python tools/spec_lint.py --spec exercises/bad-spec --tests exercises/none で点検し、直してください

## FR-001 CSV読み込み
CSVをいい感じに速く読めるといい。

## FR-002 要約と送信
CSVを読み込み、集計し、要約してメールで送ること。必要に応じて適切に処理する。
- 受入基準：正しく動くこと

## FR-002 個人情報
個人名などは出さない。

## FR-005 画面
使いやすい画面にする。
- 受入基準：
  - Given 初回利用者 / When 操作する / Then 3分以内に完了する
