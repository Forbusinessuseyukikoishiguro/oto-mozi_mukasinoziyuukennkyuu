#!/usr/bin/env python3
"""
e2e_smoke.py — 実ブラウザ（Chromium）で、モックサーバー相手に画面を通しで動かす試験。

フェーズと検証する AC（docs/spec.md）:
  A 正常系   AC-01a 表示 / AC-05 分割数の目安 / AC-03 分割 / AC-06 結合 /
             AC-08 結果表示 / AC-09a 保存名 / AC-09b BOM / UX-01 3操作で完了
  B 認証誤り AC-10b 401 の案内が出る（再試行しない）
  C 再試行   AC-10a 「再試行中」が表示され、最後は完了する（429 を模倣）
  D 中止     AC-11 中止後も完了分が残り、コピー・保存が使える
  E 接続不可 AC-10b 「Azureに接続できません」が出る（モックを止めて再現）
  共通       コンソールに想定外のエラーが出ない（AC-10b 補足）

安全性:
  - 本番の config.js は変更しない。一時フォルダに index.html と試験用設定だけを置く。
  - endpoint は localhost のため、課金は発生しない。
  - 終了時に、起動したサーバーをすべて停止する。

実行: python3 scripts/e2e_smoke.py
前提: pip install playwright && python3 -m playwright install chromium
終了コード: 0 = 全件合格 / 1 = 不合格あり
"""
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOCK_PORT = 8787
HTTP_PORT = 8100
WAV_NAME = "sample-2min.wav"
results = []  # (AC, 合否, 内容)


def record(ac, ok, note=""):
    results.append((ac, bool(ok), note))
    print(f"[{'合' if ok else '否'}] {ac} {note}")


def port_open(port):
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", port)) == 0


def wait_port(port, want_open, timeout=15):
    end = time.time() + timeout
    while time.time() < end:
        if port_open(port) == want_open:
            return True
        time.sleep(0.2)
    return False


def start_mock(extra_env=None):
    env = dict(os.environ, **(extra_env or {}))
    p = subprocess.Popen(["node", os.path.join(ROOT, "mock-server.js")], cwd=ROOT, env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    wait_port(MOCK_PORT, True)
    return p


def stop_mock(p):
    if p and p.poll() is None:
        p.terminate()
        p.wait(timeout=5)
    wait_port(MOCK_PORT, False)


def write_config(tmp, api_key):
    """試験用 config.js を一時フォルダに作る（config.mock.js の apiKey だけ差し替え）"""
    src = open(os.path.join(ROOT, "config.mock.js"), encoding="utf-8").read()
    src = src.replace('apiKey: "mock-key"', f'apiKey: "{api_key}"')
    with open(os.path.join(tmp, "config.js"), "w", encoding="utf-8") as f:
        f.write(src)


def load_page(browser, errors):
    page = browser.new_page()
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.goto(f"http://localhost:{HTTP_PORT}/index.html")
    return page


def select_file(page, tmp, split="1"):
    page.set_input_files("#file", os.path.join(tmp, WAV_NAME))
    page.wait_for_function("document.getElementById('fileInfo').textContent.includes('02:00')", timeout=20000)
    page.select_option("#splitMin", split)


def status(page):
    return page.inner_text("#status")


def error_text(page):
    return page.inner_text("#errBox") if page.is_visible("#errBox") else ""


def main():
    if not os.path.exists(os.path.join(ROOT, "test", WAV_NAME)):
        subprocess.run(["node", os.path.join(ROOT, "make-test-wav.js"), "2"], cwd=ROOT, check=True)

    tmp = tempfile.mkdtemp(prefix="e2e-azure-")
    shutil.copy(os.path.join(ROOT, "index.html"), tmp)
    shutil.copy(os.path.join(ROOT, "test", WAV_NAME), tmp)
    write_config(tmp, "mock-key")

    web = subprocess.Popen([sys.executable, "-m", "http.server", str(HTTP_PORT), "--directory", tmp],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    mock = None
    errors = []
    try:
        wait_port(HTTP_PORT, True)
        mock = start_mock()

        with sync_playwright() as p:
            browser = p.chromium.launch()

            # ---------- A. 正常系 ----------
            page = load_page(browser, errors)
            page.set_input_files("#file", os.path.join(tmp, WAV_NAME))
            page.wait_for_function("document.getElementById('fileInfo').textContent.includes('02:00')", timeout=20000)
            info = page.inner_text("#fileInfo")
            record("AC-01a", "02:00" in info and "MB" in info, f"表示: {info}")

            page.select_option("#splitMin", "1")
            est1 = page.inner_text("#estimate")
            page.select_option("#splitMin", "10")
            est10 = page.inner_text("#estimate")
            record("AC-05", "2 件" in est1 and "1 件" in est10, f"1分: {est1} / 10分: {est10}")

            page.select_option("#splitMin", "1")
            page.click("#start")
            page.wait_for_function("document.getElementById('status').textContent.includes('完了しました')", timeout=60000)
            result = page.input_value("#result")
            h1 = "--- 第1部（00:00:00〜00:01:00）---" in result
            h2 = "--- 第2部（00:01:00〜00:02:00）---" in result
            n = result.count("【モック】")
            record("AC-03", h1 and h2, "2分の音声を1分単位で2区間に分割")
            record("AC-06", h1 and h2 and n == 2, f"見出し付きで結合（【モック】{n}件）")
            record("AC-08", n == 2, "区間ごとの結果が画面に表示")

            with page.expect_download() as dl:
                page.click("#save")
            d = dl.value
            path = os.path.join(tmp, d.suggested_filename)
            d.save_as(path)
            record("AC-09a", d.suggested_filename == "sample-2min.txt", f"保存名: {d.suggested_filename}")
            with open(path, "rb") as f:
                record("AC-09b", f.read(3) == b"\xef\xbb\xbf", "先頭が BOM（EF BB BF）")
            record("UX-01", True, "選択 → 分割単位 → 開始 → 取得（保存）で完了")
            page.close()

            # ---------- B. 認証誤り（401）----------
            write_config(tmp, "wrong-key")
            page = load_page(browser, errors)
            select_file(page, tmp, "1")
            page.click("#start")
            page.wait_for_function("!document.getElementById('errBox').hidden", timeout=30000)
            msg = error_text(page)
            record("AC-10b", "401" in msg and "APIキー" in msg, f"401 の案内: {msg[:40]}…")
            page.close()
            write_config(tmp, "mock-key")

            # ---------- C. 再試行（429 を2回ごとに返す）----------
            stop_mock(mock)
            mock = start_mock({"FAIL_EVERY": "2"})
            page = load_page(browser, errors)
            select_file(page, tmp, "1")
            page.click("#start")
            saw_retry = False
            end = time.time() + 60
            while time.time() < end:
                s = status(page)
                if "再試行中" in s:
                    saw_retry = True
                if "完了しました" in s:
                    break
                time.sleep(0.1)
            n2 = page.input_value("#result").count("【モック】")
            record("AC-10a", saw_retry and n2 == 2, f"再試行表示={saw_retry}、最後まで完了（{n2}件）")
            page.close()
            stop_mock(mock)
            mock = start_mock()

            # ---------- D. 中止 ----------
            page = load_page(browser, errors)
            select_file(page, tmp, "1")
            page.click("#start")
            page.wait_for_function("document.getElementById('prog').value >= 1", timeout=30000)
            page.click("#cancel")
            page.wait_for_function("document.getElementById('status').textContent.includes('中止しました')", timeout=30000)
            st = status(page)
            kept = page.input_value("#result").count("【モック】") >= 1
            copy_on = page.is_enabled("#copy")
            record("AC-11", "1/2部" in st and kept and copy_on, f"状態: {st}（結果残存={kept}、コピー可={copy_on}）")
            page.close()

            # ---------- E. 接続不可（モックを停止）----------
            stop_mock(mock)
            mock = None
            page = load_page(browser, errors)
            select_file(page, tmp, "1")
            page.click("#start")
            page.wait_for_function("!document.getElementById('errBox').hidden", timeout=60000)
            msg = error_text(page)
            record("AC-10b", "接続できません" in msg, f"接続不可の案内: {msg[:30]}…")
            page.close()

            browser.close()

        # 共通：想定外のコンソールエラーがない（接続不可・401・429 の想定内エラーは除外）
        expected = ("401", "429", "Failed to load resource", "net::ERR_CONNECTION_REFUSED")
        unexpected = [e for e in errors if not any(x in e for x in expected)]
        record("AC-10b", not unexpected, "想定外のコンソールエラー: " + ("なし" if not unexpected else "; ".join(unexpected)))

    finally:
        stop_mock(mock)
        web.terminate()
        shutil.rmtree(tmp, ignore_errors=True)

    failed = [r for r in results if not r[1]]
    print(f"\n== 結果: 合格 {len(results) - len(failed)} / {len(results)} 件 ==")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
