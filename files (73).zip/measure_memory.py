#!/usr/bin/env python3
"""
measure_memory.py — 音声の長さごとに、ブラウザのメモリ使用量（RSS）のピークを計測する（OQ-05）。

方法:
  - 実際の index.html を Chromium で開き、ステレオ 44.1kHz の WAV（実機の録音に近い形式）を投入する。
  - 投入 → 文字起こし開始 → 完了 までの間、ブラウザのプロセス群の合計 RSS を 0.2 秒ごとに記録する。
  - 送信先はモックサーバー（課金なし）。計測対象はブラウザ側の処理のみ。

注意:
  - 計測値は「この環境（Linux・Chromium）」での値。Windows・Edge では数値が変わる。
  - 計測値は docs/measurements.md に記録して、decisions（ADR-004）の判断材料にする。

実行: python3 scripts/measure_memory.py 10 30
      （引数は音声の長さ（分）。複数指定可）
"""
import array
import os
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time

import psutil
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOCK_PORT, HTTP_PORT = 8787, 8100
RATE, CH = 44100, 2


def write_stereo_wav(path, minutes):
    """1秒ぶんのブロックを作って繰り返し書く（生成を速くするため）"""
    n_sec = minutes * 60
    block = array.array("h")
    for i in range(RATE):
        v = int(0.3 * 32767 * __import__("math").sin(2 * 3.14159 * 440 * i / RATE))
        block.extend([v, v])  # ステレオ（左右同じ）
    data = block.tobytes()
    data_len = len(data) * n_sec
    with open(path, "wb") as f:
        f.write(b"RIFF" + struct.pack("<I", 36 + data_len) + b"WAVE")
        f.write(b"fmt " + struct.pack("<IHHIIHH", 16, 1, CH, RATE, RATE * CH * 2, CH * 2, 16))
        f.write(b"data" + struct.pack("<I", data_len))
        for _ in range(n_sec):
            f.write(data)


def port_open(port):
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", port)) == 0


def browser_rss_mb():
    """python プロセスの子孫（Chromium 本体・レンダラ等）の RSS 合計（MB）"""
    total = 0
    try:
        for ch in psutil.Process().children(recursive=True):
            try:
                total += ch.memory_info().rss
            except psutil.Error:
                pass
    except psutil.Error:
        pass
    return total / 1048576


class Sampler(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.peak = 0.0
        self.stop_flag = threading.Event()

    def run(self):
        while not self.stop_flag.is_set():
            self.peak = max(self.peak, browser_rss_mb())
            time.sleep(0.2)


def make_audio(minutes, tmp, kind):
    """kind='wav': 無圧縮（最大サイズ）／ kind='mp3': 128kbps（実際の録音に近い）"""
    if kind == "wav":
        path = os.path.join(tmp, f"stereo-{minutes}min.wav")
        write_stereo_wav(path, minutes)
    else:
        path = os.path.join(tmp, f"stereo-{minutes}min.mp3")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi",
                        "-i", f"sine=frequency=440:duration={minutes * 60}",
                        "-ac", "2", "-ar", "44100", "-b:a", "128k", path], check=True)
    return path


def measure(minutes, tmp, browser, kind="wav"):
    wav = make_audio(minutes, tmp, kind)
    size_mb = os.path.getsize(wav) / 1048576
    decoded_mb = minutes * 60 * 16000 * CH * 4 / 1048576  # 16kHz・ステレオ・Float32 で展開した場合の理論値（ADR-008）

    page = browser.new_page()
    page.goto(f"http://localhost:{HTTP_PORT}/index.html")
    time.sleep(0.5)
    baseline = browser_rss_mb()

    sampler = Sampler()
    sampler.start()
    try:
        page.set_input_files("#file", wav)
        page.wait_for_function("document.getElementById('fileInfo').textContent.includes('再生時間')", timeout=600000)
        page.click("#start")
        page.wait_for_function("document.getElementById('status').textContent.includes('完了しました')", timeout=1800000)
        status = "完了"
    except Exception as e:
        status = f"失敗（{str(e)[:60]}）"
    finally:
        sampler.stop_flag.set()
        sampler.join()
        page.close()

    return {
        "kind": kind,
        "minutes": minutes,
        "file_mb": size_mb,
        "decoded_theory_mb": decoded_mb,
        "baseline_mb": baseline,
        "peak_mb": sampler.peak,
        "delta_mb": sampler.peak - baseline,
        "status": status,
    }


def main():
    # 使い方: python3 scripts/measure_memory.py [wav|mp3] 分 [分 ...]
    args = sys.argv[1:]
    kind = "wav"
    if args and args[0] in ("wav", "mp3"):
        kind = args.pop(0)
    minutes_list = [int(x) for x in args] or [10, 30]
    tmp = tempfile.mkdtemp(prefix="mem-")
    shutil.copy(os.path.join(ROOT, "index.html"), tmp)
    # 計測用の設定（本番設定は使わない）
    src = open(os.path.join(ROOT, "config.mock.js"), encoding="utf-8").read()
    open(os.path.join(tmp, "config.js"), "w", encoding="utf-8").write(src)

    web = subprocess.Popen([sys.executable, "-m", "http.server", str(HTTP_PORT), "--directory", tmp],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    mock = subprocess.Popen(["node", os.path.join(ROOT, "mock-server.js")], cwd=ROOT,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1.5)
    rows = []
    try:
        with sync_playwright() as p:
            for m in minutes_list:
                print(f"計測中: {m}分（{kind}・ステレオ44.1kHz）…", flush=True)
                browser = p.chromium.launch()  # 測定ごとに新しいブラウザ（前回のメモリが残らないように）
                rows.append(measure(m, tmp, browser, kind))
                browser.close()
    finally:
        mock.terminate()
        web.terminate()
        shutil.rmtree(tmp, ignore_errors=True)

    print("\n| 形式 | 長さ | ファイル | 展開理論値 | 開始前RSS | ピークRSS | 増分 | 結果 |")
    print("|---|---|---|---|---|---|---|---|")
    for r in rows:
        print(f"| {r['kind']} | {r['minutes']}分 | {r['file_mb']:.0f} MB | {r['decoded_theory_mb']:.0f} MB | "
              f"{r['baseline_mb']:.0f} MB | {r['peak_mb']:.0f} MB | {r['delta_mb']:.0f} MB | {r['status']} |")


if __name__ == "__main__":
    main()
