/* ============================================================================
 * mock-server.js — 開発・テスト用の模倣（モック）サーバー
 * ----------------------------------------------------------------------------
 * 目的:
 *   本番のAzure Speechに送信せず、index.html の動作（分割・再試行・結合・表示）を
 *   確認するためのローカルサーバーです。課金は発生しません。
 *
 * 起動方法:
 *   node mock-server.js
 *   FAIL_EVERY=3 node mock-server.js   ← 3回ごとに429を返し、再試行動作を確認
 *
 * 使い方:
 *   config.js を次のように変更してから、index.html を開きます。
 *     endpoint: "http://localhost:8787"
 *     apiKey:   "mock-key"
 *
 * 注意:
 *   - 応答は固定文言のダミーです。音声の内容は解析していません。
 *   - 認証・ルーティングは本番API（Fast transcription）の形に合わせていますが、
 *     完全な再現ではありません。本番確認は必ず実際のAzureで行ってください。
 *   - 外部パッケージは使わず、Node.js の標準モジュールだけで動作します。
 * ============================================================================ */

const http = require("http");

/* ---------- 設定値 ---------- */
const PORT = 8787;                                  // 待ち受けポート（config.js の endpoint と一致させる）
const KEY = "mock-key";                             // 正しいAPIキーとして扱う値（config.js の apiKey と一致させる）
const FAIL_EVERY = Number(process.env.FAIL_EVERY || 0); // 0なら失敗を起こさない。3なら3回ごとに429
let count = 0;                                      // 受信したリクエストの累計（応答文言とFAIL_EVERYの判定に使用）

http.createServer((req, res) => {

  /* ---------- CORS（ブラウザからの通信を許可） ----------
   * ブラウザは別オリジン（例: http://localhost:8000 → 8787）への通信を制限します。
   * 本番のAzureでも同様のヘッダーが必要になるため、ここで同じ仕組みを再現します。 */
  res.setHeader("Access-Control-Allow-Origin", "*");                    // すべてのオリジンを許可（テスト専用）
  res.setHeader("Access-Control-Allow-Headers", "Ocp-Apim-Subscription-Key"); // キー用ヘッダーの送信を許可
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");

  /* ---------- プリフライト（事前確認）への応答 ----------
   * カスタムヘッダー付きのPOSTの前に、ブラウザはOPTIONSで許可を確認します。
   * 204（内容なし）で「許可する」と返します。 */
  if (req.method === "OPTIONS") {
    res.writeHead(204);
    return res.end();
  }

  /* ---------- ルーティング ----------
   * 対象は「POST /speechtotext/transcriptions:transcribe」だけです。
   * それ以外は404を返します。 */
  if (req.method !== "POST" || !req.url.startsWith("/speechtotext/transcriptions:transcribe")) {
    res.writeHead(404);
    return res.end();
  }

  /* ---------- 認証チェック ----------
   * ヘッダー「Ocp-Apim-Subscription-Key」が正しいかを確認します。
   * 一致しなければ401を返します（config.js の apiKey を誤った場合の動作確認に使えます）。 */
  if (req.headers["ocp-apim-subscription-key"] !== KEY) {
    res.writeHead(401, { "Content-Type": "application/json" });
    return res.end(JSON.stringify({ error: { code: "401", message: "Access denied" } }));
  }

  /* ---------- 受信データの読み取り ----------
   * 音声データ（multipart/form-data）は分割して届きます。
   * 中身は解析せず、受信したバイト数だけを数えます（応答文言に表示するため）。 */
  let bytes = 0;
  req.on("data", (chunk) => { bytes += chunk.length; });

  req.on("end", () => {
    count++;

    /* ---------- 再試行確認用の意図的な失敗 ----------
     * FAIL_EVERY が設定されていれば、その回数ごとに429（利用上限）を返します。
     * index.html の再試行（指数バックオフ）が動くかを確認できます。 */
    if (FAIL_EVERY && count % FAIL_EVERY === 0) {
      res.writeHead(429, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ error: { code: "429", message: "Too many requests" } }));
    }

    /* ---------- 正常応答 ----------
     * 本番と同じく combinedPhrases の配列でテキストを返します。
     * 1.2秒の待ちを入れ、Azureの処理時間を模倣します（進捗表示の確認用）。 */
    setTimeout(() => {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({
        durationMilliseconds: 600000,   // ダミーの長さ（10分）
        combinedPhrases: [
          { text: `【モック】${(bytes / 1048576).toFixed(1)}MBの区間 #${count} の文字起こし結果です。` },
        ],
      }));
    }, 1200);
  });

}).listen(PORT, () => {
  console.log(`mock Azure Speech on http://localhost:${PORT}`);
});
