#!/usr/bin/env node
/* ============================================================================
 * collect-evidence.js — 試験結果・証跡を1つのフォルダに回収する
 * ----------------------------------------------------------------------------
 * 実行:
 *   node scripts/collect-evidence.js                 ← verify（build・単体・秘密情報検査）のみ
 *   node scripts/collect-evidence.js --e2e          ← ＋ブラウザ試験（Python と playwright が必要）
 *   node scripts/collect-evidence.js --e2e --measurements  ← ＋docs/measurements.md を含める
 *
 * 出力: test/results/<YYYY-MM-DD_HHMM>/
 *   verify.log / e2e.log   … 各手順の実行ログ（そのまま保存）
 *   manifest.json          … 版・環境・ハッシュ・手順ごとの結果（機械可読）
 *   report.md              … 人が読む報告書（判定欄は人が記入）
 *   index.html, docs/*.md  … 試験時点の成果物と仕様のスナップショット
 *
 * 安全のための仕組み:
 *   - config.js / config.real.js / *.wav は回収しない（APIキー・音声の混入防止）
 *   - 回収後に、秘密情報らしき文字列を検査し、結果を manifest に記録する
 *   - 自動判定は「候補」まで。合否の確定は人が行う
 * 終了コード: 0 = 全手順が完了し、秘密情報の問題なし / 1 = 不合格または問題あり
 * ============================================================================ */
"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { spawnSync } = require("child_process");

const ROOT = path.join(__dirname, "..");
const WIN = process.platform === "win32";
const flags = new Set(process.argv.slice(2));
const WITH_E2E = flags.has("--e2e");
const WITH_MEASURE = flags.has("--measurements");

// 出力フォルダ名（同じ分に2回実行すると同じ場所になる。その場合は上書きされる）
const now = new Date();
const pad = (n) => String(n).padStart(2, "0");
const stamp = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}`;
const outDir = path.join(ROOT, "test", "results", stamp);
fs.mkdirSync(outDir, { recursive: true });

// 手順を実行し、ログを保存する
function run(label, cmd, cmdArgs, logName) {
  const r = spawnSync(cmd, cmdArgs, { cwd: ROOT, encoding: "utf8", shell: WIN });
  const text = `$ ${cmd} ${cmdArgs.join(" ")}\n\n${r.stdout || ""}${r.stderr || ""}` +
               (r.error ? `\nERROR: ${r.error.message}` : "");
  fs.writeFileSync(path.join(outDir, logName), text, "utf8");
  return { label, log: logName, exitCode: r.status, ok: r.status === 0 };
}

// Python の場所を探す（Windows は python、Mac・Linux は python3 が一般的）
function findPython() {
  for (const c of ["python3", "python"]) {
    const r = spawnSync(c, ["--version"], { shell: WIN, encoding: "utf8" });
    if (r.status === 0) return c;
  }
  return null;
}

// git が無い環境でも止まらないようにする
function git(gitArgs) {
  const r = spawnSync("git", gitArgs, { cwd: ROOT, encoding: "utf8", shell: WIN });
  return r.status === 0 ? r.stdout.trim() : null;
}

function sha256(file) {
  return crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

// docs/spec.md の変更履歴から、最も新しい版番号を取る
function specVersion() {
  const p = path.join(ROOT, "docs", "spec.md");
  if (!fs.existsSync(p)) return null;
  const versions = [...fs.readFileSync(p, "utf8").matchAll(/^- (\d+\.\d+)：/gm)].map((m) => m[1]);
  return versions.length ? versions.sort((a, b) => parseFloat(b) - parseFloat(a))[0] : null;
}

// ---------- 1. 手順の実行 ----------
const steps = [];
steps.push(run("verify（build・単体テスト・秘密情報検査）", "npm", ["run", "verify"], "verify.log"));

let e2eRows = [];
if (WITH_E2E) {
  const py = findPython();
  if (!py) {
    steps.push({ label: "e2e（ブラウザ試験）", log: null, exitCode: null, ok: false, note: "python が見つからない" });
  } else {
    steps.push(run("e2e（ブラウザ試験）", py, ["scripts/e2e_smoke.py"], "e2e.log"));
  }
  const logPath = path.join(outDir, "e2e.log");
  if (fs.existsSync(logPath)) {
    // e2e_smoke.py の出力行「[合] AC-xx 内容」「[否] ...」を表に変換する
    e2eRows = fs.readFileSync(logPath, "utf8").split("\n")
      .map((l) => l.match(/^\[(合|否)\] (\S+) (.*)$/))
      .filter(Boolean)
      .map((m) => ({ result: m[1] === "合" ? "合格" : "不合格", ac: m[2], note: m[3] }));
  }
} else {
  steps.push({ label: "e2e（ブラウザ試験）", log: null, exitCode: null, ok: null, note: "未実行（--e2e 未指定）" });
}

// ---------- 2. 版・環境・ハッシュ ----------
const notes = [];
const copies = ["index.html", "docs/spec.md", "docs/decisions.md", "docs/open-questions.md", "CLAUDE.md", "package.json"];
for (const f of copies) {
  const src = path.join(ROOT, f);
  if (fs.existsSync(src)) {
    const dst = path.join(outDir, f);
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(src, dst);
  }
}
if (WITH_MEASURE && fs.existsSync(path.join(ROOT, "docs", "measurements.md"))) {
  fs.copyFileSync(path.join(ROOT, "docs", "measurements.md"), path.join(outDir, "docs", "measurements.md"));
}

const hashes = {};
for (const f of ["index.html", "src/lib.js", "src/index.html", "docs/spec.md", "docs/decisions.md", "docs/open-questions.md", "CLAUDE.md", "package.json"]) {
  const p = path.join(ROOT, f);
  if (fs.existsSync(p)) hashes[f] = sha256(p);
}

const commit = git(["rev-parse", "--short", "HEAD"]);
const porcelain = git(["status", "--porcelain"]);
if (porcelain !== null) fs.writeFileSync(path.join(outDir, "git-status.txt"), porcelain + "\n", "utf8");
const tracked = git(["ls-files", "config.js", "config.real.js"]);
if (tracked) notes.push(`警告：機密を含みうるファイルが Git の追跡対象です（${tracked}）。コミットしないでください。`);

// ---------- 3. 秘密情報の検査（回収フォルダ全体） ----------
const secretHits = [];
function scanDir(dir) {
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name);
    if (fs.statSync(full).isDirectory()) { scanDir(full); continue; }
    if (!/\.(html|md|log|json|txt|js)$/i.test(name)) continue;
    const txt = fs.readFileSync(full, "utf8");
    const re = /apiKey:\s*"([^"]*)"/g;
    let m;
    while ((m = re.exec(txt))) {
      if (!/^$|ここにキーを入力|mock-key|wrong-key/.test(m[1])) secretHits.push(`${path.relative(outDir, full)}: apiKey に実値`);
    }
    if (/\b[0-9a-f]{32}\b/i.test(txt)) secretHits.push(`${path.relative(outDir, full)}: 32桁の16進数`);
  }
}
scanDir(outDir);
const secretOk = secretHits.length === 0;

// ---------- 4. 判定（候補） ----------
const failed = steps.filter((s) => s.ok === false);
const pending = steps.filter((s) => s.ok === null);
let judgment;
if (failed.length || !secretOk) judgment = "不合格";
else if (pending.length) judgment = "未完了（未実行の手順あり）";
else judgment = "自動試験は合格（人の確認が必要）";

// ---------- 5. manifest.json ----------
const manifest = {
  collectedAt: now.toISOString(),
  stamp,
  specVersion: specVersion(),
  environment: {
    node: process.version,
    platform: `${os.type()} ${os.release()}`,
    memoryGB: Math.round(os.totalmem() / 1073741824 * 10) / 10,
  },
  git: { commit, dirty: porcelain ? porcelain.length > 0 : null },
  hashes,
  steps,
  e2e: { total: e2eRows.length, passed: e2eRows.filter((r) => r.result === "合格").length, rows: e2eRows },
  secretScan: { ok: secretOk, hits: secretHits },
  notes,
  judgment,
};
fs.writeFileSync(path.join(outDir, "manifest.json"), JSON.stringify(manifest, null, 2), "utf8");

// ---------- 6. report.md ----------
const stepRows = steps.map((s) => {
  const r = s.ok === true ? "合格" : s.ok === false ? "不合格" : "未実行";
  return `| ${s.label} | ${r} | ${s.exitCode ?? "-"} | ${s.log ?? "-"} | ${s.note ?? ""} |`;
}).join("\n");

const e2eTable = e2eRows.length
  ? ["| AC | 結果 | 内容 |", "|---|---|---|", ...e2eRows.map((r) => `| ${r.ac} | ${r.result} | ${r.note} |`)].join("\n")
  : "（ブラウザ試験は未実行、または結果を読み取れませんでした）";

const report = `# 試験報告（自動回収）

| 項目 | 内容 |
|---|---|
| 回収日時 | ${now.toLocaleString("ja-JP")} |
| 仕様の版 | ${manifest.specVersion ?? "不明"}（docs/spec.md） |
| Git コミット | ${commit ?? "（Git 未使用）"}${manifest.git.dirty ? "（未コミットの変更あり）" : ""} |
| 環境 | ${manifest.environment.platform} / Node ${manifest.environment.node} / メモリ ${manifest.environment.memoryGB}GB |
| 自動判定（候補） | **${judgment}** |

## 1. 手順ごとの結果
| 手順 | 結果 | 終了コード | ログ | 備考 |
|---|---|---|---|---|
${stepRows}

## 2. ブラウザ試験の結果（AC単位）
${e2eTable}

## 3. 秘密情報の検査
${secretOk ? "問題なし" : "問題あり：\n" + secretHits.map((h) => `- ${h}`).join("\n")}
${notes.length ? "\n## 4. 注意\n" + notes.map((n) => `- ${n}`).join("\n") : ""}

## 5. この回収では確認していない項目（必ず明記する）
- 実Azureへの接続（api-version、フォーム項目名、CORS、応答形式）：OQ-01・OQ-02
- Edge・Windows での動作：NFR-01、OQ-08
- 手動試験（TC-04 ドロップ、TC-16 フォーカス枠、TC-17 360px 表示）
- 3時間音声（FR-04）、10分超の音声のメモリ（NFR-02）：docs/measurements.md を参照
- ピースの時刻の連続化（FR-12）：未実装

## 6. 人による判定欄
- 判定: 合格 ／ 条件付き合格 ／ 不合格
- 確認者:
- 確認日:
- コメント:
`;
fs.writeFileSync(path.join(outDir, "report.md"), report, "utf8");

// ---------- 7. 結果の表示 ----------
console.log(`\n回収先: test/results/${stamp}/`);
console.log(`自動判定（候補）: ${judgment}`);
for (const s of steps) console.log(`  - ${s.label}: ${s.ok === true ? "合格" : s.ok === false ? "不合格" : "未実行"}`);
if (!secretOk) console.log("秘密情報の問題があります。回収フォルダを共有せず、manifest.json の secretScan を確認してください。");
process.exit(failed.length || !secretOk ? 1 : 0);
