# Azure Speech 文字起こしツール（CLAUDE.md）

作業を始める前に、次の3ファイルを読むこと。
- docs/spec.md（要件・受け入れ基準・現在の状態）
- docs/decisions.md（決定事項と理由）
- docs/open-questions.md（未確定事項）
- docs/measurements.md（実測値）と docs/operations.md（運用手順）

## コマンド
- 配布用HTMLを生成: `npm run build`（src/ から index.html を作る）
- 単体テスト: `npm test`
- 秘密情報チェック: `npm run check`
- まとめて検証: `npm run verify`
- ブラウザ試験（Chromium・モック使用）: `npm run e2e`（前提: pip install playwright && python3 -m playwright install chromium）
- 証跡の回収（報告書・manifest）: `npm run collect`（ブラウザ試験込みは `npm run collect:e2e`）。手順は docs/回収手順書.md。スキル: .claude/skills/evidence-collect
- メモリ計測: `npm run measure -- mp3 60`（引数: wav|mp3 と分数）。結果は docs/measurements.md に記録する
- モック試験（APIキー不要）: TEST手順書.md

## 構成
- src/index.html : テンプレート（画面・UI処理。編集はここ）
- src/lib.js     : 純粋関数（テスト対象。編集はここ）
- index.html     : 生成物。直接編集しない（build.js が作る）
- config.js      : 本番の接続設定（コミットしない）。config.example.js をコピーして作る
- config.mock.js : 試験用設定（APIキー不要）
- mock-server.js : 試験用の模倣サーバー

## ルール
1. 仕様を変えるときは、先に docs/spec.md を更新する。
2. 実装・テストには FR/NFR/AC の番号を書く（例: `// FR-03`、テスト名 `AC-UT-05 ...`）。
3. 判断を変えたら docs/decisions.md に追記する（既存の決定を消さず、「置き換え」と書く）。
4. 未確定の値（api-version、フォーム項目名など）は推測で確定させず、docs/open-questions.md に書く。
5. 完了報告は、関係する AC の合否を番号ごとに書く。
6. APIキーを src/ や index.html に書かない（`npm run check` で検出される）。
7. test/results/ と *.wav は、コミットも共有もしない。

## 完了の定義（Definition of Done）
- `npm run verify` が通る
- 変更したロジックに単体テストがある
- index.html が src/ から最新の状態で生成されている
- docs/spec.md の該当 AC の状態が更新されている
- 未確定事項が増えた場合、docs/open-questions.md に追記されている
