# folder-organizer

フォルダ構成・ドキュメント・構成管理を整理するスキルです。
**現状分析 → 改善提案 → 許可 → 移動 → 移動後レポート** の順に進めます。
**「実行」と許可するまで、1ファイルも動かしません。**

---

## 流れ

| 段階 | やること | ファイルを変える？ |
|---|---|---|
| 1. ヒアリング | 対象・使う人・目的・動かしてはいけないもの | いいえ |
| 2. 現状分析 | `analyze.py` で構成・重複・命名・Git 状態を調べる | いいえ（読み取りのみ） |
| 3. 改善提案 | あるべき構成、移動計画 `plan.csv`、参照切れ候補、dry-run 結果 | いいえ |
| 4. 移動 | **許可を得てから** `--execute` で移動。記録を残す | はい |
| 5. 移動後レポート | 整理前後の比較、移動一覧、動作確認、次の一手 | レポートを作るだけ |

## 安全の仕組み

- **既定は dry-run**：`move_plan.py` は `--execute` を付けない限り何も動かしません。
- **削除しない**：不要候補は `_to_delete/` へ移動するだけ。消すかどうかは人が決めます。
- **上書きしない**：移動先に同名があると、計画の段階で止まります。
- **対象フォルダの外に出ない**：絶対パスや `..` は使えません。
- **Git の履歴を残す**：Git 管理下のファイルは `git mv` で移動します。
- **取り消せる**：1件ごとに `move_log_<日時>.csv` を保存。`--undo` で元に戻し、空になったフォルダも片付けます。

## インストール

### Claude Code（Ubuntu／WSL）
```bash
unzip folder-organizer.zip
mkdir -p ~/.claude/skills
mv folder-organizer ~/.claude/skills/
```

### Claude Code（PowerShell）
```powershell
Expand-Archive .\folder-organizer.zip -DestinationPath .
New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null
Move-Item .\folder-organizer "$HOME\.claude\skills\"
```

必要なもの：Python 3.8 以上（標準ライブラリのみ）、Git（Git 管理のフォルダを扱う場合）。

## 使い方

```
/folder-organizer ~/projects/training-tool を整理したい
```
普通に相談しても発動します：「このフォルダ散らかってる」「docs をまとめたい」「構成を見直して」。

## スクリプトを直接使う場合

```bash
# 現状分析（読み取りのみ）→ analysis.md / analysis.json
python3 scripts/analyze.py <対象フォルダ> --out analysis

# 参照切れ候補を探す（読み取りのみ）
python3 scripts/find_refs.py plan.csv --root <対象フォルダ>

# 確認だけ（dry-run）
python3 scripts/move_plan.py plan.csv --root <対象フォルダ>

# 実行（許可を得てから）
python3 scripts/move_plan.py plan.csv --root <対象フォルダ> --execute

# 取り消し
python3 scripts/move_plan.py --undo move_log_YYYYMMDD_HHMMSS.csv --root <対象フォルダ> --execute
```

PowerShell では `python3` を `python` または `py` に読み替えてください。

## plan.csv の書き方

```csv
action,src,dst,reason
mkdir,,docs,ドキュメントを1か所に集める
move,仕様書_v3_最終.docx,docs/specs/仕様書.docx,版はGitで管理し名前から外す
move,old_script.py,_to_delete/old_script.py,不要候補（削除は人が判断）
```

| 列 | 内容 |
|---|---|
| action | `mkdir`／`move`／`rename`（`delete` は使えません） |
| src | 移動元（対象フォルダからの相対パス） |
| dst | 移動先（同上） |
| reason | 理由（レポートにそのまま載ります） |

## 分析で見る観点

直下に散らばったファイル／深すぎる階層（5以上）／空フォルダ／重複ファイル（中身が同一）／名前での版管理（`_v3` `_最終` `_コピー` `(1)` 日付）／空白・記号を含む名前／README の有無／大きいファイル／Git の状態

## 用意している構成の型

開発プロジェクト（`docs/` `src/` `tests/` `scripts/` `config/`）、研修教材（`00_guide` 〜 `99_archive`）、個人の業務フォルダ（inbox／projects／areas／resources／archive）。詳しくは SKILL.md を見てください。

## ファイル構成

```
folder-organizer/
├── SKILL.md                    # スキル本体（Claude が読む指示）
├── README.md                   # この説明書
├── scripts/
│   ├── analyze.py              # 現状分析（読み取りのみ）
│   ├── find_refs.py            # 参照切れ候補の検出（読み取りのみ）
│   └── move_plan.py            # 計画の検証・dry-run・実行・取り消し
└── templates/
    ├── plan.csv                # 移動計画のひな形
    └── report_template.md      # 移動後レポートのひな形
```

## 注意

- `find_refs.py` はファイル名の一致でも拾います。候補なので、中身を見て判断してください。
- Office ファイルの中のリンクや、共有リンク（OneDrive・Google ドライブなど）は検出できません。
- 共有フォルダの場合は、移動する前に利用者へ知らせてください。

---

作成：2026-10-26
