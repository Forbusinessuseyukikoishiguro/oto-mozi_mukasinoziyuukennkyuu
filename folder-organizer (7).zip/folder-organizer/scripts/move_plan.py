#!/usr/bin/env python3
"""移動計画の検証・実行・取り消し。
既定は「確認だけ（dry-run）」で、ファイルは動かさない。
  確認:   python3 move_plan.py plan.csv --root <対象>
  実行:   python3 move_plan.py plan.csv --root <対象> --execute     ← 許可を得てから
  取消:   python3 move_plan.py --undo move_log_YYYYMMDD_HHMMSS.csv --root <対象> [--execute]
plan.csv の列: action,src,dst,reason   action = move | mkdir | rename
  ・削除（delete）は扱わない。不要ファイルは _to_delete/ への move で表す。
  ・Git 管理下なら git mv を使い、履歴を残す。
"""
import argparse, csv, os, shutil, subprocess, sys
from datetime import datetime

def is_git(root):
    r = subprocess.run(['git', '-C', root, 'rev-parse', '--is-inside-work-tree'], capture_output=True, text=True)
    return r.returncode == 0 and r.stdout.strip() == 'true'

def tracked(root, rel):
    r = subprocess.run(['git', '-C', root, 'ls-files', '--error-unmatch', rel], capture_output=True, text=True)
    return r.returncode == 0

def load(path):
    with open(path, encoding='utf-8-sig') as f:
        return [{k: (v or '').strip() for k, v in r.items()} for r in csv.DictReader(f)]

def check(rows, root):
    errs, dsts = [], set()
    for i, r in enumerate(rows, 2):
        act, src, dst = r.get('action', ''), r.get('src', ''), r.get('dst', '')
        if act not in ('move', 'rename', 'mkdir'):
            errs.append(f'{i}行目: action「{act}」は使えません（move/rename/mkdir のみ。削除は扱わない）'); continue
        for p in (src, dst):
            if p and (os.path.isabs(p) or '..' in p.replace('\\', '/').split('/')):
                errs.append(f'{i}行目: 対象フォルダの外は指定できません: {p}')
        if act == 'mkdir':
            continue
        if not os.path.exists(os.path.join(root, src)):
            errs.append(f'{i}行目: 移動元がありません: {src}')
        if os.path.exists(os.path.join(root, dst)):
            errs.append(f'{i}行目: 移動先が既にあります（上書きしない）: {dst}')
        if dst in dsts:
            errs.append(f'{i}行目: 移動先が計画内で重複: {dst}')
        dsts.add(dst)
    return errs

def run(rows, root, execute, log_path):
    git = is_git(root)
    done = []
    for r in rows:
        act, src, dst = r['action'], r.get('src', ''), r.get('dst', '')
        if act == 'mkdir':
            print(f'[{"実行" if execute else "予定"}] mkdir {dst}')
            if execute:
                os.makedirs(os.path.join(root, dst), exist_ok=True)
            continue
        use_git = git and tracked(root, src)
        print(f'[{"実行" if execute else "予定"}] {"git mv" if use_git else "mv"} {src} -> {dst}   # {r.get("reason", "")}')
        if not execute:
            continue
        os.makedirs(os.path.dirname(os.path.join(root, dst)) or root, exist_ok=True)
        if use_git:
            subprocess.run(['git', '-C', root, 'mv', src, dst], check=True)
        else:
            shutil.move(os.path.join(root, src), os.path.join(root, dst))
        done.append({'action': act, 'src': src, 'dst': dst, 'reason': r.get('reason', ''), 'method': 'git mv' if use_git else 'mv',
                     'time': datetime.now().isoformat(timespec='seconds')})
        with open(log_path, 'w', newline='', encoding='utf-8') as f:  # 1件ごとに保存（途中で止まっても取り消せる）
            w = csv.DictWriter(f, fieldnames=list(done[0].keys())); w.writeheader(); w.writerows(done)
    return done

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('plan', nargs='?'); ap.add_argument('--root', required=True)
    ap.add_argument('--execute', action='store_true'); ap.add_argument('--undo')
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    if a.undo:
        rows = [{'action': 'move', 'src': r['dst'], 'dst': r['src'], 'reason': '取り消し'} for r in reversed(load(a.undo))]
        log = f'undo_log_{stamp}.csv'
    else:
        if not a.plan:
            sys.exit('plan.csv を指定してください')
        rows = load(a.plan); log = f'move_log_{stamp}.csv'
    errs = check(rows, root)
    if errs:
        print('NG: 計画に問題があります。何も動かしていません。'); print('\n'.join(errs)); sys.exit(1)
    if not a.execute:
        print(f'--- 確認のみ（dry-run）: {len(rows)} 件。ファイルは動かしていません ---')
    done = run(rows, root, a.execute, log)
    if a.execute and a.undo:  # 取り消しで空になったフォルダだけを片付ける（中身があれば残す）
        for r in rows:
            d = os.path.dirname(os.path.join(root, r['src']))
            while d.startswith(root + os.sep) and os.path.isdir(d) and not os.listdir(d):
                os.rmdir(d); print(f'[実行] 空フォルダを片付け: {os.path.relpath(d, root)}'); d = os.path.dirname(d)
    if a.execute:
        print(f'OK: {len(done)} 件を移動。記録: {log}')
        print(f'取り消し: python3 move_plan.py --undo {log} --root "{root}" --execute')
    else:
        print('問題なし。実行するには許可を得てから --execute を付けてください。')

if __name__ == '__main__':
    main()
