#!/usr/bin/env python3
"""移動するファイルを参照している箇所を探す（読み取り専用）。
使い方: python3 find_refs.py plan.csv --root <対象>  または  --log move_log_*.csv
リンク切れ・import切れ・設定ファイルのパス切れを、移動の前後で確認する。
"""
import argparse, csv, os
TEXT = {'.md', '.txt', '.html', '.htm', '.css', '.js', '.ts', '.tsx', '.jsx', '.py', '.json', '.yaml', '.yml', '.toml',
        '.ini', '.cfg', '.sh', '.ps1', '.bat', '.cmd', '.java', '.xml', '.properties', '.env.example', '.dockerfile', ''}
SKIP = {'.git', 'node_modules', '__pycache__', '.venv', 'venv', 'dist', 'build'}
ap = argparse.ArgumentParser(); ap.add_argument('csv'); ap.add_argument('--root', required=True); a = ap.parse_args()
root = os.path.abspath(a.root)
with open(a.csv, encoding='utf-8-sig') as f:
    targets = [r['src'] for r in csv.DictReader(f) if r.get('src')]
keys = {t: {t.replace('\\', '/'), os.path.basename(t)} for t in targets}
hits = 0
for d, ds, fs in os.walk(root):
    ds[:] = [x for x in ds if x not in SKIP]
    for fn in fs:
        ext = os.path.splitext(fn)[1].lower()
        if ext not in TEXT and fn not in ('Dockerfile', 'Makefile'):
            continue
        p = os.path.join(d, fn)
        try:
            with open(p, encoding='utf-8', errors='ignore') as fp:
                for n, line in enumerate(fp, 1):
                    for t, ks in keys.items():
                        if any(k and k in line for k in ks):
                            print(f'{os.path.relpath(p, root)}:{n}: [{t}] {line.strip()[:120]}'); hits += 1
        except OSError:
            pass
print(f'--- 参照候補 {hits} 件（ファイル名だけの一致も含む。中身を見て判断） ---')
